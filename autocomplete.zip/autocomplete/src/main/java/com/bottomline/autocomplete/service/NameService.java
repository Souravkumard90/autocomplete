package com.bottomline.autocomplete.service;

import com.bottomline.autocomplete.entity.Name;
import com.bottomline.autocomplete.pojo.Trie;
import com.bottomline.autocomplete.repository.NameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import com.bottomline.autocomplete.repository.NameRepository;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

@Service
public class NameService {

    @Autowired
    private NameRepository nameRepository;

    private Trie trie;

    @PostConstruct
    public void init() {
        // Load names from the database
        List<Name> names = nameRepository.findAll();

        // Create and populate the Trie
        trie = new Trie();
        for (Name name : names) {
            trie.insert(name.getName());
        }
    }

    public List<String> autocomplete(String prefix) {
        return trie.findWordsWithPrefix(prefix);
    }
}
