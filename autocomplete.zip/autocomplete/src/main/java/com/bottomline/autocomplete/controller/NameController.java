package com.bottomline.autocomplete.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bottomline.autocomplete.service.NameService;

import java.util.List;

@RestController
public class NameController {

    @Autowired
    private NameService nameService;

    @GetMapping("/autocomplete")
    public List<String> autocomplete(@RequestParam String prefix) {
        return nameService.autocomplete(prefix);
    }
}
